The "engines" folder is for backup purpose only. Files in this directory are meant to
be copied out to work with different themes and demos.
